#!/usr/bin/env python3

import mido
import json
import time
import os


FUSION_IN = "CH345"
SYNTH_OUT = "FLUID Synth"

FILE = "fusion.json"



def load_json():

    if not os.path.exists(FILE):

        return {}


    with open(FILE) as f:

        return json.load(f)



def find_input():

    for port in mido.get_input_names():

        if FUSION_IN.lower() in port.lower():

            return port


    return None



def find_output():

    for port in mido.get_output_names():

        if SYNTH_OUT.lower() in port.lower():

            return port


    return None



def panic(out):

    for ch in range(16):

        out.send(
            mido.Message(
                "control_change",
                channel=ch,
                control=123,
                value=0
            )
        )

        out.send(
            mido.Message(
                "control_change",
                channel=ch,
                control=121,
                value=0
            )
        )



def send_program(out, channel, part):

    bank = part.get(
        "bank",
        0
    )

    program = part.get(
        "program",
        0
    )


    out.send(
        mido.Message(
            "control_change",
            channel=channel,
            control=0,
            value=bank
        )
    )


    out.send(
        mido.Message(
            "program_change",
            channel=channel,
            program=program
        )
    )



def load_mix(mix_id, out, performances):


    if mix_id not in performances:

        print()
        print(
            "Mix inconnu:",
            mix_id
        )

        return



    mix = performances[mix_id]


    print()
    print("======================")
    print(
        "Performance:",
        mix.get(
            "name",
            mix_id
        )
    )
    print(
        "Fusion Mix:",
        mix_id
    )
    print("======================")


    panic(out)

    time.sleep(0.05)



    for part_id, part in mix["parts"].items():


        midi_channel = (
            part["midi_channel"] - 1
        )


        print(
            "PART",
            part_id,
            "→ CH",
            part["midi_channel"],
            "→",
            part.get(
                "name",
                "Unknown"
            ),
            "Program",
            part.get(
                "program",
                0
            )
        )


        send_program(
            out,
            midi_channel,
            part
        )



def main():


    performances = load_json()


    fusion_port = find_input()

    if not fusion_port:

        raise Exception(
            "Fusion MIDI introuvable"
        )


    synth_port = find_output()

    if not synth_port:

        raise Exception(
            "FluidSynth MIDI introuvable"
        )


    print(
        "Fusion :",
        fusion_port
    )

    print(
        "Synth :",
        synth_port
    )


    bank = 0


    with mido.open_input(
        fusion_port
    ) as inp:


        with mido.open_output(
            synth_port
        ) as out:


            print()
            print(
                "Attente des changements de Mix..."
            )


            for msg in inp:


                if msg.type == "control_change":


                    if msg.control == 0:

                        bank = msg.value



                elif msg.type == "program_change":


                    mix_id = (
                        f"{bank}:{msg.program}"
                    )


                    print()
                    print(
                        "===================="
                    )

                    print(
                        "Mix Fusion détecté"
                    )

                    print(
                        "Bank:",
                        bank
                    )

                    print(
                        "Program:",
                        msg.program
                    )

                    print(
                        "ID:",
                        mix_id
                    )

                    print(
                        "===================="
                    )


                    load_mix(
                        mix_id,
                        out,
                        performances
                    )



if __name__ == "__main__":

    main()
