#!/usr/bin/env python3

import json
import os
import mido
import time

FILE = "fusion.json"
GM_FILE = "gm_instruments.json"

MIDI_OUT_NAME = "FLUID Synth"


def find_output():

    for port in mido.get_output_names():

        if MIDI_OUT_NAME.lower() in port.lower():

            return port


    return None


def test_instrument(channel, instrument):

    port_name = find_output()


    if not port_name:

        print(
            "QSynth introuvable"
        )

        return



    with mido.open_output(port_name) as out:


        ch = channel - 1


        # Bank Select MSB
        out.send(
            mido.Message(
                "control_change",
                channel=ch,
                control=0,
                value=instrument["bank"]
            )
        )


        # Program Change
        out.send(
            mido.Message(
                "program_change",
                channel=ch,
                program=instrument["program"]
            )
        )


        time.sleep(0.1)


        # Note test C4
        out.send(
            mido.Message(
                "note_on",
                channel=ch,
                note=60,
                velocity=80
            )
        )


        time.sleep(1)


        out.send(
            mido.Message(
                "note_off",
                channel=ch,
                note=60,
                velocity=0
            )
        )


def load_instruments():

    with open(GM_FILE) as f:
        data = json.load(f)


    instruments = []


    for key, inst in data.items():

        # seulement les sons GM bank 0
        if inst["bank"] == 0:

            instruments.append(inst)


    instruments.sort(
        key=lambda x: x["program"]
    )


    return instruments


INSTRUMENTS = load_instruments()

def load():

    if not os.path.exists(FILE):
        return {}

    with open(FILE) as f:
        return json.load(f)



def save(data):

    with open(FILE, "w") as f:
        json.dump(
            data,
            f,
            indent=2
        )



def choose_instrument():

    print()


    for i, inst in enumerate(
        INSTRUMENTS,
        start=1
    ):

        print(
            f"{i} - {inst['name']} "
            f"(Program {inst['program']})"
        )


    while True:

        choix = input(
            "Choix (q pour quitter) : "
        )


        if choix.lower() == "q":

            return None


        try:

            num = int(choix)


            if 1 <= num <= len(INSTRUMENTS):

                inst = INSTRUMENTS[num-1]


                selected = {
                    "bank": inst["bank"],
                    "program": inst["program"],
                    "name": inst["name"]
                }
                return selected


        except ValueError:

            pass


        print(
            "Choix invalide"
        )


def edit_mix(mix_id):

    data = load()


    if mix_id not in data:

        print(
            "Mix inconnu"
        )

        return


    mix = data[mix_id]


    if "parts" not in mix:

        print(
            "Aucune PART détectée"
        )

        return



    print()
    print("====================")
    print(
        "Edition Mix",
        mix_id
    )
    print("====================")


    for part_id, part in mix["parts"].items():


        midi_channel = part["midi_channel"]


        print()
        print(
            "PART",
            part_id
        )

        print(
            "Canal MIDI :",
            midi_channel
        )


        while True:


            rep = input(
                "Configurer cette PART ? (o/n/q) : "
            )


            if rep.lower() == "q":

                save(data)

                print(
                    "Edition terminée"
                )

                return



            if rep.lower() == "n":

                break



            if rep.lower() == "o":


                instrument = choose_instrument()


                if instrument:

                    test = input(
                        "Tester ce son ? (o/n) : "
                    )


                    if test.lower()=="o":

                        test_instrument(
                            midi_channel,
                            instrument
                        )

                if instrument is None:

                    save(data)

                    print(
                        "Edition terminée"
                    )

                    return



                part.update(
                    instrument
                )


                save(data)


                print(
                    "Sauvegardé :",
                    part
                )

                break



    save(data)


    print()
    print(
        "Mix complet sauvegardé"
    )



def list_mixes():

    data = load()


    if not data:

        print(
            "Aucun Mix"
        )

        return


    print()

    for mix_id, mix in data.items():

        print(
            mix_id,
            "-",
            mix.get(
                "name",
                ""
            )
        )



def main():


    while True:


        print()
        print("===================")
        print("Fusion Editor")
        print("===================")
        print("1 - Liste des Mix")
        print("2 - Editer un Mix")
        print("3 - Quitter")


        choix = input("> ")


        if choix == "1":

            list_mixes()



        elif choix == "2":


            mix = input(
                "Numéro du Mix (ex: 2:4) : "
            )


            edit_mix(mix)



        elif choix == "3":

            break



if __name__ == "__main__":

    main()
