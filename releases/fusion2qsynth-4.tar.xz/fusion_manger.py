#!/usr/bin/env python3

import json
import os


FILE = "fusion.json"


def load():

    if not os.path.exists(FILE):
        return {}

    with open(FILE) as f:
        return json.load(f)



def save(data):

    with open(FILE,"w") as f:
        json.dump(
            data,
            f,
            indent=2
        )



def list_mixes():

    data=load()

    print()

    if not data:
        print("Aucun Mix appris")
        return


    for mix,value in data.items():

        print(
            mix,
            "-",
            value.get(
                "name",
                ""
            )
        )



def show_mix():

    data=load()

    mix=input(
        "Mix (ex: 0:16): "
    )


    if mix not in data:
        print(
            "Inconnu"
        )
        return


    print()

    print(
        data[mix]["name"]
    )

    print("----------------")

    for ch,part in data[mix]["channels"].items():

        print(
            "CH",
            ch,
            part
        )



def main():

    while True:

        print()
        print("================")
        print("Fusion Manager")
        print("================")
        print("1 - Liste des Mix")
        print("2 - Voir un Mix")
        print("3 - Quitter")


        choix=input("> ")


        if choix=="1":
            list_mixes()


        elif choix=="2":
            show_mix()


        elif choix=="3":
            break



if __name__=="__main__":

    main()
