#!/usr/bin/env python3

import mido
import json
import time


FILE = "performances.json"

FUSION = "CH345"


def find_port():

    for p in mido.get_input_names():

        if FUSION.lower() in p.lower():
            return p

    return None



def load():

    try:
        with open(FILE) as f:
            return json.load(f)

    except:
        return {}



def save(data):

    with open(FILE,"w") as f:
        json.dump(
            data,
            f,
            indent=2
        )



port=find_port()

if not port:
    raise Exception(
        "Fusion introuvable"
    )


print("Ecoute :", port)
print()
print("Sélectionne un Mix")
print("Puis joue une note")
print("Ctrl+C pour quitter")
print()


bank=0
current_mix=None


with mido.open_input(port) as inp:

    detected=[]

    for msg in inp:


        if msg.type=="control_change":


            if msg.control==0:

                bank=msg.value



        elif msg.type=="program_change":


            current_mix=f"{bank}:{msg.program}"

            detected=[]


            print()
            print("----------------")
            print(
                "Nouveau Mix:",
                current_mix
            )

            print(
                "Jouez une note..."
            )



        elif msg.type in ["note_on", "note_off"]:


            if msg.velocity > 0 and current_mix:


                midi_channel = msg.channel + 1


                if midi_channel not in detected:

                    detected.append(midi_channel)

                    part_number = len(detected)

                    print(
                        "PART",
                        part_number,
                        "→ MIDI CH",
                        midi_channel
                    )


                    data = load()


                    # Créer le Mix si nécessaire
                    if current_mix not in data:

                        data[current_mix] = {
                            "name":
                            f"Fusion Mix {current_mix}",

                            "parts": {}
                        }


                    # Ajouter la PART
                    data[current_mix]["parts"][
                        str(part_number)
                    ] = {
                        "midi_channel":
                        midi_channel
                    }


                    save(data)