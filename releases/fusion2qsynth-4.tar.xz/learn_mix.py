#!/usr/bin/env python3

import mido
import json
import time


FILE = "fusion.json"

FUSION = "CH345"

CAPTURE_TIME = 5


def load():

    try:
        with open(FILE) as f:
            return json.load(f)

    except:
        return {}



def save(data):

    with open(FILE,"w") as f:
        json.dump(
            data,
            f,
            indent=2
        )



def find_port():

    for p in mido.get_input_names():

        if FUSION.lower() in p.lower():
            return p

    return None



port=find_port()

if not port:
    raise Exception(
        "Fusion introuvable"
    )


print(
    "Ecoute :",
    port
)

print()
print(
    "Sélectionne un Mix"
)
print(
    "Joue une note ou un accord"
)
print(
    "Capture automatique 5 secondes"
)
print()


bank=0
current_mix=None
capturing=False
channels=[]



with mido.open_input(port) as inp:


    inp.callback = None

    start=0


    while True:

        msg = inp.poll()

        now=time.time()


        if msg is None:

            if capturing and now-start > CAPTURE_TIME:

                capturing=False

                if current_mix:

                    data=load()

                    data[current_mix]={

                        "name":
                        f"Fusion Mix {current_mix}",

                        "parts":{}

                    }


                    for index,ch in enumerate(
                        channels,
                        start=1
                    ):

                        data[current_mix]["parts"][
                            str(index)
                        ] = {

                            "midi_channel": ch
                        }


                    save(data)

                    print()
                    print(
                        "Mix sauvegardé"
                    )

                    print(
                        data[current_mix]
                    )


            time.sleep(0.01)

            continue


        if msg.type=="control_change":

            if msg.control==0:

                bank=msg.value



        elif msg.type=="program_change":


            current_mix=f"{bank}:{msg.program}"

            channels=[]

            capturing=True

            start=now


            print()
            print("----------------")
            print(
                "Nouveau Mix:",
                current_mix
            )

            print(
                "Capture..."
            )



        elif capturing:


            if msg.type in [
                "note_on",
                "note_off"
            ]:


                ch=msg.channel+1


                if ch not in channels:

                    channels.append(ch)

                    print(
                        "Canal détecté:",
                        ch
                    )



        if capturing and now-start > CAPTURE_TIME:


            capturing=False


            if current_mix:


                data=load()


                data[current_mix]={

                    "name":
                    f"Fusion Mix {current_mix}",

                    "parts":{}

                }


                for index,ch in enumerate(
                    channels,
                    start=1
                ):


                    data[current_mix][
                        "parts"
                    ][str(index)]={

                        "midi_channel":
                        ch

                    }


                save(data)


                print()
                print(
                    "Mix sauvegardé"
                )


                print(
                    data[current_mix]
                )
