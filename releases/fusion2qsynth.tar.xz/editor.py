#!/usr/bin/env python3

import json
import os

from config import MIX_FILE

INSTRUMENTS = {
    1: "Acoustic Grand Piano",
    2: "Electric Piano 1",
    3: "Drawbar Organ",
    4: "Acoustic Guitar",
    5: "Acoustic Bass",
    6: "Strings Ensemble",
    7: "Choir Aahs",
    8: "French Horn",
    9: "Synth Brass 1",
    10: "Warm Pad",
    11: "Standard Kit"
}


def load():

    if not os.path.exists(MIX_FILE):
        return {}

    with open(MIX_FILE) as f:
        return json.load(f)


def save(data):

    with open(MIX_FILE,"w") as f:
        json.dump(
            data,
            f,
            indent=2
        )


def choose_instrument():

    print()

    for number,name in INSTRUMENTS.items():
        print(
            number,
            "-",
            name
        )

    while True:

        try:
            c=int(input("Choix : "))

            if c in INSTRUMENTS:
                return INSTRUMENTS[c]

        except:
            pass

        print("Choix invalide")


def show_mix(mix,data):

    print()
    print("----------------")
    print("Mix",mix)
    print("----------------")

    if mix not in data:
        print("Non configuré")
        return

    for ch,value in data[mix].get("channels",{}).items():

        print(
            "CH",
            ch,
            "→",
            value["instrument"]
        )


def show_mix_detail(mix, data):

    print()
    print("==============================")
    print("Mix :", mix)
    print("Nom :", data[mix]["name"])
    print("==============================")

    channels = data[mix].get("channels", {})

    for ch in range(1,17):

        info = channels.get(str(ch))

        if info:
            print(
                f"CH{ch:02d} : {info['instrument']}"
            )
        else:
            print(
                f"CH{ch:02d} : ---"
            )

    print()


def edit_channel(ch, data, mix):

    current = data[mix]["channels"].get(str(ch), {})

    if current:
        print(
            "Actuel :",
            current["instrument"]
        )

    instrument = choose_instrument()

    entry = {
        "instrument": instrument
    }

    if ch == 10:
        entry["drum"] = True

    data[mix]["channels"][str(ch)] = entry


def edit_mix(mix):

    data=load()

    if mix not in data or "channels" not in data[mix]:

        old_name = "Fusion Mix " + mix

        if mix in data and "name" in data[mix]:
            old_name = data[mix]["name"]

        data[mix] = {
            "name": old_name,
            "channels": {}
        }

    print()
    print("Edition Mix",mix)
    print("----------------")


    while True:

        show_mix_detail(
            mix,
            data
        )

        action=input(
            "Canal à modifier (1-16), a=tous, q=quitter : "
        ).lower()


        if action=="q":
            break


        if action=="a":

            for ch in range(1,17):

                answer=input(
                    f"CH{ch} modifier ? (o/n) : "
                ).lower()

                if answer=="o":
                    edit_channel(
                        ch,
                        data,
                        mix
                    )

            continue


        try:

            ch=int(action)

            if 1 <= ch <= 16:

                edit_channel(
                    ch,
                    data,
                    mix
                )

        except:

            print(
                "Choix invalide"
            )

    save(data)

    print()
    print("Mix sauvegardé.")



if __name__=="__main__":

    data=load()

    mix=input(
        "Numéro du Mix Fusion : "
    )

    if mix not in data:
        data[mix]={
            "name":"Fusion Mix "+mix,
            "channels":{}
        }


    edit_mix(mix)

