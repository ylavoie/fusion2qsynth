from fpm.performance import Performance


p=Performance(
    "Ballade",
    65
)


p.add_part(
    1,
    0
)

p.add_part(
    2,
    48
)

p.add_part(
    3,
    32
)


p.show()

