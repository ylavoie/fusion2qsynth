#!/usr/bin/env python3

import json
import mido


MIX_FILE = "mixes.json"


def load_mixes():
    try:
        with open(MIX_FILE) as f:
            return json.load(f)
    except:
        return {}


def save_mixes(data):
    with open(MIX_FILE,"w") as f:
        json.dump(data,f,indent=2)


def find_port(keyword, ports):

    for p in ports:
        if keyword.lower() in p.lower():
            return p

    return None



inputs=mido.get_input_names()

fusion=find_port("CH345",inputs)

if not fusion:
    raise Exception("Fusion MIDI absent")


print("Ecoute :",fusion)

midi=mido.open_input(fusion)


mixes=load_mixes()


print()
print("Sélectionne un Mix sur le Fusion")
print("Ctrl+C pour quitter")
print()


current_mix=None
parts={}


for msg in midi:


    if msg.type=="program_change":


        ch=msg.channel+1


        print(
            "Program Change",
            "CH",
            ch,
            "Program",
            msg.program
        )


        # Canal 1 = changement de Mix
        if ch==1:

            current_mix=str(msg.program)

            print()
            print("Nouveau Mix :",current_mix)

            parts={}

            mixes[current_mix]={
                "name":
                "Fusion Mix "+current_mix,
                "raw_programs":
                parts
            }

            save_mixes(mixes)

            print("Mix sauvegardé")

        else:

            if current_mix:

                parts[ch]=msg.program

                print(
                    "Part enregistrée:",
                    ch,
                    msg.program
                )


                mixes[current_mix]={
                    "name":
                    "Fusion Mix "+current_mix,

                    "raw_programs":
                    parts
                }


                save_mixes(mixes)

