#!/usr/bin/env python3

import json
import mido
import subprocess
import os

from config import MIX_FILE


def load():

    if not os.path.exists(MIX_FILE):
        return {}

    with open(MIX_FILE) as f:
        return json.load(f)


def find_port(name,ports):

    for p in ports:
        if name.lower() in p.lower():
            return p

    return None



inputs=mido.get_input_names()

fusion=find_port(
    "CH345",
    inputs
)


if not fusion:
    raise Exception(
        "Fusion introuvable"
    )


print(
    "Ecoute:",
    fusion
)


midi=mido.open_input(fusion)


for msg in midi:


    if msg.type!="program_change":
        continue


    # Canal global du Fusion
    if msg.channel==0:


        mix=str(msg.program)


        print()
        print(
            "Mix détecté:",
            mix
        )


        mixes=load()


        if mix not in mixes:

            print(
                "Mix inconnu"
            )

            answer=input(
                "Créer ce Mix ? (o/n) "
            )


            if answer.lower()=="o":

                subprocess.run(
                    [
                     "./editor.py"
                    ],
                    input=mix+"\n",
                    text=True
                )

        else:

            print(
                "Mix configuré:",
                mixes[mix]["name"]
            )
