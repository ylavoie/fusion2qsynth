import json
import subprocess


FILE="soundfonts.json"


def load():

    with open(FILE) as f:
        return json.load(f)



def load_soundfonts():

    fonts=load()

    for name,data in fonts.items():

        print(
            "Chargement:",
            name
        )

        subprocess.run(
            [
                "fluidsynth",
                "-a",
                "jack",
                "-z",
                data["file"]
            ]
        )

