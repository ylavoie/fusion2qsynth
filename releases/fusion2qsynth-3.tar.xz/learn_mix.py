#!/usr/bin/env python3

import mido
import json
import time


FILE = "performances.json"

FUSION = "CH345"


def find_port():

    for p in mido.get_input_names():

        if FUSION.lower() in p.lower():
            return p

    return None



def load():

    try:
        with open(FILE) as f:
            return json.load(f)

    except:
        return {}



def save(data):

    with open(FILE,"w") as f:
        json.dump(
            data,
            f,
            indent=2
        )



port=find_port()

if not port:
    raise Exception(
        "Fusion introuvable"
    )


print("Ecoute :", port)
print()
print("Sélectionne un Mix")
print("Puis joue une note")
print("Ctrl+C pour quitter")
print()


bank=0
current_mix=None


with mido.open_input(port) as inp:

    detected=set()

    for msg in inp:


        if msg.type=="control_change":


            if msg.control==0:

                bank=msg.value



        elif msg.type=="program_change":


            current_mix=f"{bank}:{msg.program}"

            detected=set()


            print()
            print("----------------")
            print(
                "Nouveau Mix:",
                current_mix
            )

            print(
                "Jouez une note..."
            )



        elif msg.type=="note_on":


            if msg.velocity > 0 and current_mix:


                ch=msg.channel+1


                if ch not in detected:


                    detected.add(ch)


                    print(
                        "PART détectée CH",
                        ch
                    )


                    data=load()


                    data[current_mix]={

                        "name":
                        f"Fusion Mix {current_mix}",

                        "channels":{}

                    }


                    for c in sorted(detected):

                        data[current_mix]["channels"][
                            str(c)
                        ]={}


                    save(data)
