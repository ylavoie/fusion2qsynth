#!/usr/bin/env python3

import json


PERF_FILE="performances.json"
INST_FILE="instruments.json"



def load(file):

    with open(file) as f:
        return json.load(f)



def save(file,data):

    with open(file,"w") as f:
        json.dump(
            data,
            f,
            indent=2
        )



def choose_instrument():

    instruments=load(INST_FILE)

    print()

    for key,value in instruments.items():

        print(
            key,
            "-",
            value["name"]
        )


    while True:

        c=input(
            "Choix (q pour quitter): "
        )


        if c=="q":
            return None


        if c in instruments:
            return instruments[c]



def edit_mix(mix):

    performances=load(PERF_FILE)


    if mix not in performances:

        print(
            "Mix inconnu"
        )

        return



    channels=performances[mix]["channels"]


    print()
    print(
        "Edition Mix",
        mix
    )
    print("----------------")


    for ch in channels:


        while True:


            print()
            print(
                "Configurer CH"+ch+" ? (o/n/q)"
            )

            rep=input("> ")


            if rep=="q":
                return


            if rep=="n":
                break


            if rep=="o":

                inst=choose_instrument()


                if inst:

                    channels[ch]=inst


                break



    save(
        PERF_FILE,
        performances
    )



mix=input(
    "Numéro du Mix Fusion : "
)


edit_mix(mix)
