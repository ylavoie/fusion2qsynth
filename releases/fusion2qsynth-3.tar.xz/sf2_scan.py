#!/usr/bin/env python3

import subprocess
import json
import sys


def scan(sf2):

    cmd=[
        "sf2dump",
        sf2
    ]

    result=subprocess.run(
        cmd,
        capture_output=True,
        text=True
    )


    presets=[]


    for line in result.stdout.splitlines():

        if "preset" in line.lower():

            presets.append(line.strip())


    return presets



if __name__=="__main__":

    if len(sys.argv)<2:
        print(
            "Usage: sf2_scan fichier.sf2"
        )
        exit()


    sf2=sys.argv[1]

    data=scan(sf2)


    with open(
        "presets.json",
        "w"
    ) as f:

        json.dump(
            data,
            f,
            indent=2
        )


    print(
        len(data),
        "presets trouvés"
    )
