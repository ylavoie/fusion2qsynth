#!/usr/bin/env python3

import json
import time
import mido


CONFIG="mixes.json"


def find_port(pattern, ports):
    for p in ports:
        if pattern.lower() in p.lower():
            return p
    return None


def load_config():
    with open(CONFIG) as f:
        return json.load(f)


inputs=mido.get_input_names()
outputs=mido.get_output_names()

fusion=find_port("CH345", inputs)
qsynth=find_port("FLUID", outputs)

if not fusion:
    raise Exception("Fusion MIDI introuvable")

if not qsynth:
    raise Exception("QSynth introuvable")


print("Entrée :", fusion)
print("Sortie :", qsynth)


midi_in=mido.open_input(fusion)
midi_out=mido.open_output(qsynth)


print("En attente des changements de Mix...")


for msg in midi_in:

    if msg.type != "program_change":
        continue

    mix_id=str(msg.program)

    mixes=load_config()

    if mix_id not in mixes:
        print("Mix inconnu :", mix_id)
        continue

    mix=mixes[mix_id]

    print("\nMix :", mix["name"])

    for ch,data in mix["channels"].items():

        channel=int(ch)-1
        #print("\nch : ", ch, ", data : ", data);

        # Bank Select MSB
        midi_out.send(
            mido.Message(
                "control_change",
                channel=channel,
                control=0,
                value=data.get("msb",0)
            )
        )

        # Bank Select LSB
        midi_out.send(
            mido.Message(
                "control_change",
                channel=channel,
                control=32,
                value=data.get("lsb",0)
            )
        )

        # Program Change
        midi_out.send(
            mido.Message(
                "program_change",
                channel=channel,
                program=data["program"]
            )
        )

        print(
            "CH", ch,
            "Program", data["program"]
        )
