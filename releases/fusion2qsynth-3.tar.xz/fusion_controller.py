#!/usr/bin/env python3

import json
import os
import mido
import time

current_bank_msb = {}
current_bank_lsb = {}

MIX_FILE = "mixes.json"

FUSION_PORT = "CH345"
FLUID_PORT = "FLUID Synth"


def load_mixes():

    if not os.path.exists(MIX_FILE):
        return {}

    with open(MIX_FILE) as f:
        return json.load(f)



def find_port(search, ports):

    search = search.lower()

    print("\nPorts disponibles:")
    for p in ports:
        print(" -", p)

    for p in ports:

        if search in p.lower():
            return p

    return None


def send_program(out, channel, data):

    bank = data.get("bank", 0)
    program = data.get("program", 0)


    # Bank Select MSB
    out.send(
        mido.Message(
            "control_change",
            channel=channel,
            control=0,
            value=bank
        )
    )


    # Program Change
    out.send(
        mido.Message(
            "program_change",
            channel=channel,
            program=program
        )
    )



def load_mix(out, mix):

    mixes = load_mixes()


    if mix not in mixes:

        print(
            "Mix inconnu:",
            mix
        )

        return


    performance = mixes[mix]


    print()
    print("==========================")
    print(
        "Performance:",
        performance["name"]
    )
    print(
        "Fusion Mix:",
        mix
    )
    print("==========================")


    for ch, part in performance.get(
        "channels",
        {}
    ).items():


        channel = int(ch)-1
        bank = part.get("bank",0)

        # GM drums : canal 10
        if channel == 9:
            bank = 0


        # Banque MSB
        out.send(
            mido.Message(
                "control_change",
                channel=channel,
                control=0,
                value=bank
            )
        )


        # Banque LSB
        out.send(
            mido.Message(
                "control_change",
                channel=channel,
                control=32,
                value=0
            )
        )


        # Program Change
        out.send(
            mido.Message(
                "program_change",
                channel=channel,
                program=part.get("program",0)
            )
        )


        print(
            "CH",
            ch,
            "→",
            part.get("name","Program "+str(part.get("program")))
        )


# Ports MIDI

inputs = mido.get_input_names()
outputs = mido.get_output_names()


fusion = find_port(
    FUSION_PORT,
    inputs
)

fluid = find_port(
    FLUID_PORT,
    outputs
)


if not fusion:
    raise Exception(
        "Fusion MIDI introuvable"
    )


if not fluid:
    raise Exception(
        "FluidSynth MIDI introuvable"
    )



print("Fusion :", fusion)
print("FluidSynth :", fluid)


inp = mido.open_input(fusion)
out = mido.open_output(fluid)



print()
print("Fusion Controller actif")
print("Ctrl+C pour quitter")
print()



for msg in inp:


    ch = msg.channel

    if msg.type in [
        "note_on",
        "note_off",
        "pitchwheel",
        "aftertouch"
    ]:

        out.send(msg)

    # Contrôleurs sauf Bank Select
    elif msg.type == "control_change":


        if msg.control not in [0,32]:
            out.send(msg)


        if msg.control == 0:

            current_bank_msb[ch] = msg.value

            print(
                "Bank MSB CH",
                ch+1,
                "=",
                msg.value
            )


        elif msg.control == 32:

            current_bank_lsb[ch] = msg.value

            print(
                "Bank LSB CH",
                ch+1,
                "=",
                msg.value
            )


    elif msg.type == "program_change":

    	msb = current_bank_msb.get(ch, 0)

    	mix_id = f"{msb}:{msg.program}"

    	print()
    	print("====================")
    	print("Mix Fusion détecté")
    	print("Bank :", msb)
    	print("Program :", msg.program)
    	print("ID :", mix_id)
    	print("====================")


    	load_mix(
            out,
            mix_id
    	)
