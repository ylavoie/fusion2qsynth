#!/usr/bin/env python3

import mido
import json
import os
import time


FUSION_IN = "CH345"
FILE = "fusion.json"

CAPTURE_TIME = 5



def load_json():

    if os.path.exists(FILE):

        with open(FILE, "r") as f:
            return json.load(f)

    return {}



def save_json(data):

    with open(FILE, "w") as f:

        json.dump(
            data,
            f,
            indent=2,
            ensure_ascii=False
        )



def find_input():

    for port in mido.get_input_names():

        if FUSION_IN.lower() in port.lower():

            return port

    return None



def main():


    port_name = find_input()


    if not port_name:

        raise Exception(
            "Fusion MIDI introuvable"
        )


    print(
        "Ecoute :",
        port_name
    )

    print()
    print(
        "Sélectionne un Mix Fusion"
    )

    print(
        "La capture démarre automatiquement"
    )

    print(
        "Ctrl+C pour quitter"
    )



    data = load_json()


    # mémoire MIDI permanente
    banks = {}
    programs = {}


    current_mix = None

    capture_active = False
    capture_start = 0

    parts_seen = {}



    with mido.open_input(port_name) as inp:


        while True:


            now = time.time()



            #
            # Fin de capture automatique
            #
            if capture_active:


                if now - capture_start >= CAPTURE_TIME:


                    capture_active = False


                    print()
                    print("====================")
                    print("Fin de capture")
                    print("====================")

                    if current_mix:


                        used_channels = []


                        for part in parts_seen.values():

                            used_channels.append(
                                part["midi_channel"]
                            )


                        if len(used_channels) != len(set(used_channels)):

                            print()
                            print("ERREUR :")
                            print("Plusieurs PARTS utilisent le même canal MIDI.")
                            print("Réglage Fusion requis.")
                            print()


                        else:

                            data[current_mix]["parts"] = {}


                            for i, part in enumerate(
                                parts_seen.values(),
                                start=1
                            ):

                                data[current_mix]["parts"][
                                    str(i)
                                ] = part


                            save_json(data)


                            print()
                            print(
                                "Capture terminée"
                            )

                            print(
                                len(parts_seen),
                                "PART(s) sauvegardée(s)"
                            )

                            print()


            #
            # Poll MIDI
            #
            for msg in inp.iter_pending():



                #
                # Bank MSB
                #
                if msg.type == "control_change":


                    if msg.control == 0:

                        banks[msg.channel] = msg.value



                #
                # Program Change
                #
                elif msg.type == "program_change":


                    programs[msg.channel] = msg.program



                    #
                    # Canal principal Fusion
                    #
                    if msg.channel == 0:


                        bank = banks.get(
                            msg.channel,
                            0
                        )


                        current_mix = (
                            f"{bank}:{msg.program}"
                        )


                        parts_seen = {}


                        if current_mix not in data:


                            data[current_mix] = {

                                "name":
                                    f"Fusion Mix {current_mix}",

                                "parts": {}

                            }



                        capture_active = True

                        capture_start = time.time()



                        print()
                        print(
                            "===================="
                        )

                        print(
                            "Nouveau Mix:",
                            current_mix
                        )

                        print(
                            "Capture PARTS:",
                            CAPTURE_TIME,
                            "secondes"
                        )

                        print(
                            "Jouez une note..."
                        )



                #
                # Notes = découverte PART
                #
                elif msg.type == "note_on":


                    if not capture_active:

                        continue


                    if msg.velocity == 0:

                        continue



                    ch = msg.channel



                    if ch not in parts_seen:


                        parts_seen[ch] = {


                            "midi_channel": ch + 1,

                            "bank":
                                banks.get( ch, 0 ),

                            "program":
                                programs.get( ch, 0 )

                        }



                        print(
                            "PART",
                            len(parts_seen),
                            "→ CH",
                            ch + 1,
                            "Bank",
                            parts_seen[ch]["bank"],
                            "Program",
                            parts_seen[ch]["program"]
                        )



            time.sleep(0.01)



if __name__ == "__main__":

    main()
