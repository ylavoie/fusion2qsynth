#!/usr/bin/env python3

import mido

from fusion_lib import (
    load_json,
    find_fusion_input,
    build_channel_map,
    note_name,
    print_part
)


FILE = "fusion.json"

FUSION_IN = "CH345"


def main():

    data = load_json()

    channel_map = build_channel_map(
        data
    )

    port_name = find_fusion_input()

    if not port_name:

        raise Exception(
            "Fusion MIDI introuvable"
        )

    print(
        "Monitoring :",
        port_name
    )

    with mido.open_input(port_name) as inp:

        for msg in inp:

            if msg.type not in (
                "note_on",
                "note_off"
            ):
                continue

            ch = msg.channel + 1

            print()

            print(
                msg.type.upper()
            )

            print(
                " Canal :",
                ch
            )

            print(
                " Note :",
                note_name(
                    msg.note
                )
            )

            print(
                " Velocity :",
                msg.velocity
            )

            info = channel_map.get(
                ch
            )

            if info:

                print()

                print(
                    " Mix :",
                    info["mix_id"]
                )

                print(
                    " PART :",
                    info["part_id"]
                )

                print_part(
                    info["part_id"],
                    info["part"]
                )

            else:

                print(
                    " PART inconnue"
                )

if __name__ == "__main__":

    main()
