#!/usr/bin/env python3

import subprocess
import json
import sys
import re


sf2 = sys.argv[1]


result = subprocess.run(
    ["sf2dump", sf2],
    capture_output=True,
    text=True
)


instruments = {}

program = 0


for line in result.stdout.splitlines():

    match = re.search(
        r'^\s*(.+?)\s+\(Preset:\s*(\d+),\s*Bank:\s*(\d+)',
        line
    )

    if match:

        name = match.group(1).strip()
        program = int(match.group(2))
        bank = int(match.group(3))

        key = f"{bank}:{program}"

        if key not in instruments:

            instruments[key] = {
                "bank": bank,
                "program": program,
                "name": name
            }



with open(
    "gm_instruments.json",
    "w"
) as f:

    json.dump(
        instruments,
        f,
        indent=2
    )


print(
    len(instruments),
    "instruments sauvegardés"
)
