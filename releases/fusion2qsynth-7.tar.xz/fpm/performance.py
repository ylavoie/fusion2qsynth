class Performance:


    def __init__(self, name, mix):

        self.name=name
        self.mix=mix
        self.parts={}



    def add_part(
        self,
        channel,
        program,
        bank=0
    ):

        self.parts[channel]={
            "program":program,
            "bank":bank
        }



    def show(self):

        print()
        print("===================")
        print(self.name)
        print("Mix:",self.mix)
        print("===================")

        for ch,p in self.parts.items():

            print(
                "CH",
                ch,
                "Program",
                p["program"],
                "Bank",
                p["bank"]
            )

