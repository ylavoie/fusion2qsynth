MIX_FILE = "mixes.json"
GM_FILE = "gm.json"
