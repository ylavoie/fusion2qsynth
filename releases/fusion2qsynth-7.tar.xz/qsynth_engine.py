import json
import mido

from config import MIX_FILE, GM_FILE


def find_port(name, ports):

    for p in ports:
        if name.lower() in p.lower():
            return p

    return None



def load(file):

    with open(file) as f:
        return json.load(f)



def send_program(out, channel, data):


    if data.get("drum",False):
        channel = 9


    msb = data.get("msb",0)
    lsb = data.get("lsb",0)
    program = data.get("program",0)


    out.send(
        mido.Message(
            "control_change",
            channel=channel,
            control=0,
            value=msb
        )
    )


    out.send(
        mido.Message(
            "control_change",
            channel=channel,
            control=32,
            value=lsb
        )
    )


    out.send(
        mido.Message(
            "program_change",
            channel=channel,
            program=program
        )
    )


def open_qsynth():

    outputs=mido.get_output_names()

    port=find_port(
        "FLUID",
        outputs
    )

    if not port:
        raise Exception(
            "QSynth introuvable"
        )

    return mido.open_output(port)



def load_mix(out, mix):

    mixes=load(MIX_FILE)

    if mix not in mixes:
        print(
            "Mix absent:",
            mix
        )
        return False


    print()
    print(
        "Chargement QSynth:",
        mixes[mix]["name"]
    )


    for ch,data in mixes[mix]["channels"].items():

	send_program(
    	    out,
            int(ch)-1,
            data
        )

        print(
            "CH",
            ch,
            "→",
            data["instrument"]
        )


    return True

