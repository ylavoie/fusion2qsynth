#!/usr/bin/env python3

import json
import mido
import time


MIX_FILE = "mixes.json"
GM_FILE = "gm.json"


def load_json(file):
    with open(file) as f:
        return json.load(f)


def find_port(keyword, ports):

    for p in ports:
        if keyword.lower() in p.lower():
            return p

    return None


def send_program(out, channel, instrument, drum=False):

    gm = load_json(GM_FILE)

    if instrument not in gm:
        print("Instrument inconnu :", instrument)
        return


    if drum:
        channel = 9   # MIDI canal 10


    program = gm[instrument]


    # Bank MSB
    out.send(
        mido.Message(
            "control_change",
            channel=channel,
            control=0,
            value=0
        )
    )


    # Bank LSB
    out.send(
        mido.Message(
            "control_change",
            channel=channel,
            control=32,
            value=0
        )
    )


    # Program Change
    out.send(
        mido.Message(
            "program_change",
            channel=channel,
            program=program
        )
    )


def main():

    inputs = mido.get_input_names()
    outputs = mido.get_output_names()


    fusion = find_port("CH345", inputs)
    fluid = find_port("FLUID", outputs)


    if not fusion:
        raise Exception("Fusion MIDI non trouvé")


    if not fluid:
        raise Exception("QSynth non trouvé")


    print("Fusion :", fusion)
    print("QSynth :", fluid)


    midi_in = mido.open_input(fusion)
    midi_out = mido.open_output(fluid)


    mixes = load_json(MIX_FILE)


    print()
    print("fusion2qsynth actif")
    print("--------------------")


    for msg in midi_in:


        if msg.type != "program_change":
            continue


        mix_number = str(msg.program)


        if mix_number not in mixes:
            print("Mix inconnu :", mix_number)
            continue


        mix = mixes[mix_number]


        print()
        print("MIX :", mix["name"])
        print("----------------")


        for ch,data in mix["channels"].items():

            send_program(
                midi_out,
                int(ch)-1,
                data["instrument"],
                data.get("drum",False)
            )


            print(
                "CH",
                ch,
                "→",
                data["instrument"]
            )


if __name__ == "__main__":
    main()
