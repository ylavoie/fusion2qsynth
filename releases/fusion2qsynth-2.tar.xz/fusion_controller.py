#!/usr/bin/env python3

import json
import mido
import os

import qsynth_engine


from config import MIX_FILE



def load_mixes():

    if not os.path.exists(MIX_FILE):
        return {}

    with open(MIX_FILE) as f:
        return json.load(f)



def find_port(name, ports):

    for p in ports:
        if name.lower() in p.lower():
            return p

    return None



inputs=mido.get_input_names()


fusion=find_port(
    "CH345",
    inputs
)


if not fusion:
    raise Exception(
        "Fusion MIDI absent"
    )



print(
    "Fusion:",
    fusion
)



midi=mido.open_input(fusion)

qsynth=qsynth_engine.open_qsynth()



print()
print("fusion_controller actif")
print("------------------------")



for msg in midi:


    if msg.type!="program_change":
        continue


    # Canal global Fusion
    if msg.channel != 0:
        continue


    mix=str(msg.program)


    print()
    print(
        "Mix Fusion:",
        mix
    )


    mixes=load_mixes()


    if mix in mixes:

        qsynth_engine.load_mix(
            qsynth,
            mix
        )


    else:

        print(
            "Mix inconnu."
        )

        print(
            "Utiliser editor.py pour le créer."
        )
